﻿namespace DataLayer.Models
{
    public enum Language
    {
        English,
        Croatian
    }
    public enum Championship
    {
        Male,
        Female
    }
}
