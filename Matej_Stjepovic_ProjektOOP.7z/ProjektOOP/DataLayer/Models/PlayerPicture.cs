﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataLayer.Models
{
    public class PlayerPicture
    {
        public string PictureName{ get; set; }
        
    }
}
