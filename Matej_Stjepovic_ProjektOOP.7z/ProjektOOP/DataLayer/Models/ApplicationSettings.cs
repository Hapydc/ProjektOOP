﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataLayer.Models
{
    public class ApplicationSettings
    {
        public Language Language { get; set; }
        public Championship Championship { get; set; }
    }

}
